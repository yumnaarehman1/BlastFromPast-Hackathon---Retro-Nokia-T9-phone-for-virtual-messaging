let currentInput = '';
let typedLetter = '';
let t9Map = {
  '2': ['A', 'B', 'C'],
  '3': ['D', 'E', 'F'],
  '4': ['G', 'H', 'I'],
  '5': ['J', 'K', 'L'],
  '6': ['M', 'N', 'O'],
  '7': ['P', 'Q', 'R', 'S'],
  '8': ['T', 'U', 'V'],
  '9': ['W', 'X', 'Y', 'Z']
};

let keyPressCount = {};
let lastKey = '';
let timer;

function typeKey(key) {
  clearTimeout(timer);

  if (key === lastKey) {
    keyPressCount[key]++;
  } else {
    if (typedLetter) {
      currentInput += typedLetter;
    }
    keyPressCount = {};
    keyPressCount[key] = 0;
    lastKey = key;
  }

  let letters = t9Map[key];
  typedLetter = letters[keyPressCount[key] % letters.length];
  updateDisplay(currentInput + typedLetter);

  timer = setTimeout(() => {
    currentInput += typedLetter;
    typedLetter = '';
    keyPressCount = {};
    lastKey = '';
    updateDisplay(currentInput);
  }, 1000);
}

function updateDisplay(text) {
  document.getElementById('display').innerText = text;
}

function clearText() {
  currentInput = '';
  typedLetter = '';
  keyPressCount = {};
  lastKey = '';
  updateDisplay('');
}

async function sendMessage() {
  const phone = document.getElementById('phone').value;
  const finalMessage = typedLetter ? currentInput + typedLetter : currentInput;

  if (!phone || !finalMessage) {
    alert("Please enter a phone number and a message.");
    return;
  }

  const response = await fetch('http://localhost:3000/send-sms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to: phone, message: finalMessage })
  });

  const data = await response.json();
  alert(data.message);
  clearText();
}


